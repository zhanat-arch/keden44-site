import {runKeden} from './keden-api.mjs';
import {config} from './config.mjs';
chrome.action.onClicked.addListener(async()=>{
  const url=chrome.runtime.getURL('index.html');
  const existing=(await chrome.tabs.query({})).find(tab=>tab.url===url);
  if(existing)await chrome.tabs.update(existing.id,{active:true});
  else await chrome.tabs.create({url});
});
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(sender.id!==chrome.runtime.id||sender.url!==chrome.runtime.getURL('index.html'))return false;
  (async()=>{
    if(Date.now()>=Date.parse(config.expiresAt))throw Error('Срок временного инструмента завершился 15 ноября 2026 года');
    if(!['inspect','apply'].includes(message.command)||!Number.isInteger(message.tabId))throw Error('Некорректная команда');
    const tab=await chrome.tabs.get(message.tabId);
    if(!/^https:\/\/keden\.kgd\.gov\.kz\/declarations\/DT\/2\/[A-Z0-9]+(?:\/|$)/.test(tab.url||''))throw Error('Выберите открытый черновик ДТ KEDEN');
    const results=await chrome.scripting.executeScript({target:{tabId:message.tabId},world:'MAIN',func:runKeden,args:[message.command,message.payload,config.expiresAt]});
    return results[0]?.result;
  })().then(result=>reply({ok:true,result})).catch(error=>reply({ok:false,error:error.message||String(error)}));
  return true;
});
