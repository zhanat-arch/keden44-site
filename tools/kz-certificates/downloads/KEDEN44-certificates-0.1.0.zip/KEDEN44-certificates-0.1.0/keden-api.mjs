// Executed inside the selected KEDEN tab; credentials never leave that tab.
export async function runKeden(command, payload, expiresAt) {
  const path=location.pathname.match(/^\/declarations\/DT\/2\/([A-Z0-9]+)(?:\/|$)/);
  if(location.origin!=='https://keden.kgd.gov.kz'||!path)throw Error('Откройте черновик ДТ');
  const declarationId=path[1];
  if(!payload||!Array.isArray(payload.groups)||!payload.groups.length||payload.groups.length>2000)throw Error('Нет списка документов');
  const tokenNow=()=>JSON.parse(localStorage.getItem('auth-storage')||'null')?.state?.token?.access_token;
  const subject=()=>{
    const token=tokenNow();if(!token)throw Error('Войдите в KEDEN');
    try{const claims=JSON.parse(atob(token.split('.')[1].replace(/-/g,'+').replace(/_/g,'/')));return claims.sub||token;}
    catch{return token;}
  };
  const account=subject();
  function guard(){
    if(Date.now()>=Date.parse(expiresAt))throw Error('Срок инструмента завершён');
    if(location.pathname.match(/^\/declarations\/DT\/2\/([A-Z0-9]+)(?:\/|$)/)?.[1]!==declarationId||subject()!==account)throw Error('ДТ или аккаунт изменились. Операция остановлена');
    if(!/Статус:\s*Черновик/u.test(document.body.innerText))throw Error('Статус «Черновик» не подтверждён');
    if([...document.querySelectorAll('[role="dialog"]')].some(node=>node.getClientRects().length))throw Error('Закройте формы редактирования KEDEN перед запуском');
  }
  async function req(path,method='GET',body){
    guard();
    if(!/^(declaration|handbook)\//.test(path))throw Error('Запрос вне разрешённых маршрутов');
    const headers={Authorization:'Bearer '+tokenNow(),Accept:'application/json'};
    const xsrf=document.cookie.split(';').map(x=>x.trim()).find(x=>x.startsWith('XSRF-TOKEN='));
    if(xsrf)headers['X-XSRF-TOKEN']=decodeURIComponent(xsrf.slice(11));
    if(body)headers['Content-Type']='application/json';
    const response=await fetch('/api/v1/'+path,{method,headers,body:body?JSON.stringify(body):undefined,credentials:'include',signal:AbortSignal.timeout(10000)});
    const raw=await response.text();let data;try{data=JSON.parse(raw);}catch{data=null;}
    if(!response.ok)throw Error('KEDEN: HTTP '+response.status+' '+String(data?.message||'').slice(0,250));
    if(data===null)throw Error('KEDEN не вернул JSON');
    return data;
  }
  const list=value=>Array.isArray(value)?value:Array.isArray(value?.content)?value.content:null;
  const products=await req('declaration/products/declaration/'+declarationId+'/index-orders');
  if(!Array.isArray(products)||!products.length)throw Error('KEDEN не вернул товары');
  if(payload.goodsCount&&products.length!==payload.goodsCount)throw Error(`В списке ${payload.goodsCount} товаров, в открытой ДТ ${products.length}. Выбрана другая ДТ`);
  const byNumber=new Map();
  for(const product of products){
    if(!product.id||!Number.isInteger(Number(product.indexOrder))||byNumber.has(Number(product.indexOrder)))throw Error('Неоднозначная нумерация товаров KEDEN');
    byNumber.set(Number(product.indexOrder),product);
  }
  for(const row of payload.groups){
    if(!['01401','01402','01403'].includes(row.code)||row.country!=='KZ'||!row.number||row.number.length>300||!/^\d{4}-\d{2}-\d{2}$/.test(row.date)||!['0','1','2','3'].includes(row.presentationFeature)||!Array.isArray(row.products)||!row.products.length)throw Error('Недопустимая запись сертификата');
    if(row.products.some(n=>!Number.isInteger(n)||!byNumber.has(n)))throw Error('В ДТ нет одного из указанных товаров: '+row.number);
  }
  const identity=JSON.stringify({declarationId,account,products:products.map(p=>[p.id,p.indexOrder])});
  const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(identity));
  const binding=[...new Uint8Array(digest)].map(n=>n.toString(16).padStart(2,'0')).join('');
  if(command==='apply'&&(payload.binding!==binding||payload.declarationId!==declarationId))throw Error('Предварительная проверка устарела');
  const read=async number=>{
    const data=await req('declaration/documents/by-target/'+encodeURIComponent(byNumber.get(number).id)+'?page=0&size=1000');
    const rows=list(data);if(!rows||Number(data.totalElements||0)>1000)throw Error('Список документов неполон');return rows;
  };
  const relevant=[...new Set(payload.groups.flatMap(row=>row.products))];
  const cache=new Map();
  for(const number of relevant)cache.set(number,await read(number));
  const same=(doc,row)=>doc.documentType?.code===row.code&&doc.docNumber===row.number;
  const exact=(doc,row)=>same(doc,row)&&doc.docDate===row.date&&(doc.startDate||'')===row.startDate&&(doc.endDate||'')===row.endDate&&doc.country?.letterCodeShort==='KZ';
  const inspectRow=row=>{
    const matches=row.products.map(n=>(cache.get(n)||[]).filter(d=>same(d,row)));
    if(matches.some(d=>d.length>1||d.some(doc=>!exact(doc,row))))return 'conflict';
    if(matches.every(d=>d.length===1))return 'existing';
    if(matches.some(d=>d.length))return 'partial';
    return 'create';
  };
  const states=payload.groups.map(row=>({number:row.number,code:row.code,products:row.products,status:inspectRow(row)}));
  if(command==='inspect')return {declarationId,binding,goodsCount:products.length,states};
  if(command!=='apply')throw Error('Неизвестная команда');
  if(states.some(row=>row.status==='conflict'||row.status==='partial'))throw Error('Есть несовпадающие или частично существующие записи. Проверьте их вручную; ничего не записано');
  const types=list(await req('handbook/entries/search/documents_and_information_types_classifier'));
  const countries=list(await req('handbook/country'));
  const features=list(await req('handbook/entries/search/document_presentation_feature'));
  const only=(items,predicate,label)=>{const found=items?.filter(predicate);if(found?.length!==1)throw Error('Неоднозначный справочник: '+label);return found[0];};
  const country=only(countries,c=>c.letterCodeShort==='KZ','страна KZ');
  const result={created:0,existing:0,verifiedLinks:0,errors:[],declarationId};
  for(const row of payload.groups){
    if(inspectRow(row)==='existing'){result.existing++;continue;}
    let attempted=false;
    try{
      // Re-read only affected products immediately before a write; never replay a timed-out PUT.
      for(const number of row.products)cache.set(number,await read(number));
      if(inspectRow(row)==='existing'){result.existing++;continue;}
      if(inspectRow(row)!=='create')throw Error('Запись изменилась после предварительной проверки');
      const type=only(types,x=>x.code===row.code&&!x.deleted,row.code);
      const feature=only(features,x=>x.code===row.presentationFeature&&!x.deleted,'представление '+row.presentationFeature);
      const ids=row.products.map(n=>byNumber.get(n).id);
      const numbers=[...new Set(row.products)].sort((a,b)=>a-b), ranges=[];
      for(let i=0;i<numbers.length;i++){let last=i;while(numbers[last+1]===numbers[last]+1)last++;ranges.push(last===i?String(numbers[i]):numbers[i]+'-'+numbers[last]);i=last;}
      const dto={document:{documentType:type,name:row.name||type.ru,docNumber:row.number,docDate:row.date,startDate:row.startDate||null,endDate:row.endDate||null,country,presentationFeature:feature,files:[]},deliveryFlag:false,rangeIOs:ranges.join(',')};
      attempted=true;
      const saved=await req('declaration/documents/product-additional/save/'+encodeURIComponent(ids[0]),'PUT',{dto,mapToProductIds:ids});
      const savedId=saved?.document?.id;
      if(!savedId)throw Error('KEDEN не вернул ID сохранённого документа');
      for(const number of row.products){
        const docs=await read(number);cache.set(number,docs);
        if(!docs.some(doc=>doc.id===savedId&&exact(doc,row)))throw Error('Связь с товаром '+number+' не подтверждена');
        result.verifiedLinks++;
      }
      result.created++;
    }catch(error){
      result.errors.push({number:row.number,writeAttempted:attempted,message:attempted?'Сохранение могло выполниться. Повторите предварительную проверку перед новым запуском. '+error.message:error.message});
      break;
    }
  }
  return result;
}
