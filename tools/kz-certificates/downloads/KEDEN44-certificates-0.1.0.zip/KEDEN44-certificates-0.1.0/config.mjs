export const config = Object.freeze({
  version: '0.1.0',
  expiresAt: '2026-11-16T00:00:00+05:00',
  codes: ['01401', '01402', '01403'],
  country: 'KZ',
  supportUrl: 'https://keden44.com/support/',
  donateUrl: 'https://boosty.to/zhanat-arch?locale=ru_RU',
  donateText: 'Если инструмент решил вашу проблему — поддержите проект',
});
