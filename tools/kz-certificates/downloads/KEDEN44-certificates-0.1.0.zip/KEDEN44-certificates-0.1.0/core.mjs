export const HEADERS = ['Товары', 'Код документа', 'Номер документа', 'Дата документа', 'Дата начала', 'Дата окончания', 'Страна документа', 'Наименование документа', 'Код представления'];
export const CODES = ['01401', '01402', '01403'];
const text = value => String(value ?? '').trim();
export function expandRange(value, maximum = 10000) {
  const out = new Set();
  for (const token of text(value).split(',')) {
    const match = token.trim().match(/^(\d+)(?:\s*[-–]\s*(\d+))?$/);
    if (!match) throw Error('Некорректный диапазон товаров: ' + value);
    const first = Number(match[1]), last = Number(match[2] ?? match[1]);
    if (first < 1 || last < first || last > maximum) throw Error('Диапазон товаров вне допустимых границ: ' + value);
    for (let n = first; n <= last; n++) out.add(n);
  }
  return [...out].sort((a, b) => a - b);
}
export function compactRange(numbers) {
  const items = [...new Set(numbers)].sort((a, b) => a - b), out = [];
  for (let i = 0; i < items.length; i++) {
    let last = i; while (items[last + 1] === items[last] + 1) last++;
    out.push(last === i ? String(items[i]) : `${items[i]}-${items[last]}`); i = last;
  }
  return out.join(',');
}
export function isoDate(value, optional = true) {
  if (value === null || value === undefined || value === '') {
    if (optional) return ''; throw Error('Не указана дата документа');
  }
  if (value instanceof Date) {
    if (!Number.isFinite(value.getTime())) throw Error('Некорректная дата');
    return value.toISOString().slice(0, 10);
  }
  if (typeof value === 'number') {
    if (!Number.isInteger(value) || value < 61 || value > 100000) throw Error('Некорректная дата Excel');
    return new Date(Date.UTC(1899, 11, 30) + value * 86400000).toISOString().slice(0, 10);
  }
  let raw = text(value), match = raw.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
  if (match) raw = `${match[3]}-${match[2]}-${match[1]}`;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(raw) || !Number.isFinite(Date.parse(raw + 'T00:00:00Z')) || new Date(raw + 'T00:00:00Z').toISOString().slice(0, 10) !== raw) throw Error('Некорректная дата: ' + text(value));
  return raw;
}
export function validateGroups(groups) {
  if (!Array.isArray(groups) || !groups.length || groups.length > 2000) throw Error('Список должен содержать от 1 до 2000 документов');
  const unique = new Map(), identity = new Map();
  for (const input of groups) {
    const row = {code: text(input.code).padStart(5, '0'), number: text(input.number), country: text(input.country).toUpperCase(),
      date: isoDate(input.date, false), startDate: isoDate(input.startDate), endDate: isoDate(input.endDate),
      name: text(input.name), presentationFeature: text(input.presentationFeature), products: expandRange(input.products)};
    if (!CODES.includes(row.code) || row.country !== 'KZ') throw Error('В списке допускаются только КЗ-документы 01401, 01402, 01403');
    if (!row.number || row.number.length > 300 || row.name.length > 1000) throw Error('Проверьте номер и наименование документа');
    if (!['0', '1', '2', '3'].includes(row.presentationFeature)) throw Error('Не указан код представления документа');
    if (row.endDate && row.endDate < (row.startDate || row.date)) throw Error('Дата окончания раньше даты начала: ' + row.number);
    const base = JSON.stringify([row.code, row.number]);
    const signature = JSON.stringify([row.date, row.startDate, row.endDate, row.country, row.name, row.presentationFeature]);
    if (identity.has(base) && identity.get(base) !== signature) throw Error('Разные реквизиты у одного документа: ' + row.number);
    identity.set(base, signature);
    if (unique.has(base)) unique.get(base).products = [...new Set([...unique.get(base).products, ...row.products])].sort((a,b)=>a-b);
    else unique.set(base, row);
  }
  return [...unique.values()];
}
export function parseXml(source) {
  if (typeof source !== 'string' || source.length > 20000000 || /<!DOCTYPE|<!ENTITY/i.test(source)) throw Error('XML слишком большой или содержит неподдерживаемые объявления');
  const doc = new DOMParser().parseFromString(source, 'application/xml');
  if (doc.getElementsByTagName('parsererror').length) throw Error('Не удалось прочитать XML');
  const local = (parent, key) => [...parent.children].filter(node => node.localName === key);
  const field = (parent, key) => {
    const nodes = local(parent, key); if (nodes.length > 1) throw Error('Неоднозначное поле XML: ' + key);
    return nodes[0]?.textContent.trim() || '';
  };
  const goods = [...doc.getElementsByTagNameNS('*', 'GDGoodsItemDetails')];
  if (!goods.length || goods.length > 10000) throw Error('В XML не найдены товары ДТ');
  const numbers = new Set(), rows = [];
  for (const item of goods) {
    const raw = field(item, 'ConsignmentItemOrdinal'), number = Number(raw);
    if (!/^\d+$/.test(raw) || number < 1 || numbers.has(number)) throw Error('Некорректный или повторяющийся номер товара в XML');
    numbers.add(number);
    for (const node of local(item, 'PresentedDocDetails')) {
      const code = field(node, 'DocKindCode'), country = field(node, 'UnifiedCountryCode').toUpperCase();
      if (!CODES.includes(code) || country !== 'KZ') continue;
      const presenting = local(node, 'DocumentPresentingDetails')[0];
      rows.push({products: String(number), code, country, number: field(node, 'DocId'), name: field(node, 'DocName'),
        date: field(node, 'DocCreationDate'), startDate: field(node, 'DocStartDate'), endDate: field(node, 'DocValidityDate'),
        presentationFeature: presenting ? field(presenting, 'DocPresentKindCode') : ''});
      node.remove();
    }
  }
  const groups = rows.length ? validateGroups(rows) : [];
  const serialized = new XMLSerializer().serializeToString(doc).replace(/^<\?xml\b[^?]*\?>\s*/i, '');
  const xml = '<?xml version="1.0" encoding="utf-8"?>\n' + serialized;
  const verified = new DOMParser().parseFromString(xml, 'application/xml');
  if (verified.getElementsByTagName('parsererror').length || verified.getElementsByTagNameNS('*', 'GDGoodsItemDetails').length !== goods.length) throw Error('Не удалось проверить подготовленный XML');
  return {xml, groups, goodsCount: goods.length, removedCount: rows.length};
}
export async function makeWorkbook(ExcelJS, groups, metadata = {}) {
  const book = new ExcelJS.Workbook(), sheet = book.addWorksheet('КЗ сертификаты');
  sheet.addRow(HEADERS);
  for (const row of groups) sheet.addRow([compactRange(row.products), row.code, row.number,
    new Date(row.date + 'T00:00:00Z'), row.startDate ? new Date(row.startDate + 'T00:00:00Z') : null,
    row.endDate ? new Date(row.endDate + 'T00:00:00Z') : null, row.country, row.name, row.presentationFeature]);
  sheet.columns.forEach((column, index) => { column.width = [40,16,45,18,18,18,18,25,20][index]; column.numFmt = [3,4,5].includes(index) ? 'dd.mm.yyyy' : '@'; });
  sheet.getRow(1).height = 32;
  sheet.getRow(1).eachCell(cell => {cell.font = {name:'Arial',size:10,bold:true,color:{argb:'FFFFFFFF'}};cell.fill={type:'pattern',pattern:'solid',fgColor:{argb:'FF125965'}};cell.alignment={wrapText:true,vertical:'middle'};});
  sheet.views = [{state:'frozen',ySplit:1}]; sheet.autoFilter = {from:'A1',to:`I${groups.length+1}`};
  const info = book.addWorksheet('Источник');
  info.addRows([['Формат','KZCERT1'],['Товаров в ДТ',metadata.goodsCount || null],['SHA256 XML',metadata.sourceHash || ''],['Исходный файл',metadata.filename || '']]);
  info.getColumn(1).width=22;info.getColumn(2).width=70;
  return book.xlsx.writeBuffer();
}
export async function readWorkbook(ExcelJS, buffer) {
  const book = new ExcelJS.Workbook(); await book.xlsx.load(buffer);
  const sheet = book.getWorksheet('КЗ сертификаты') || book.worksheets[0];
  if (!sheet || sheet.rowCount < 2 || sheet.rowCount > 2001) throw Error('В Excel нет списка сертификатов или слишком много строк');
  for (let i=0;i<HEADERS.length;i++) if (text(sheet.getRow(1).getCell(i+1).value)!==HEADERS[i]) throw Error('Заголовки Excel не соответствуют списку сертификатов');
  const rows=[];
  for(let n=2;n<=sheet.rowCount;n++) {
    const values=Array.from({length:9},(_,i)=>sheet.getRow(n).getCell(i+1).value);
    if(values.every(value=>value===null||value===''))continue;
    if(values.some(value=>value&&typeof value==='object'&&!(value instanceof Date)))throw Error('В строке '+n+' есть формула или неподдерживаемое значение');
    rows.push({products:values[0],code:values[1],number:values[2],date:values[3],startDate:values[4],endDate:values[5],country:values[6],name:values[7],presentationFeature:values[8]});
  }
  const info=book.getWorksheet('Источник'), goodsCount=Number(info?.getCell('B2').value)||null;
  return {groups:validateGroups(rows),goodsCount};
}
